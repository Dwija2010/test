<% response.sendRedirect(request.getContextPath() + "/courses"); %>
