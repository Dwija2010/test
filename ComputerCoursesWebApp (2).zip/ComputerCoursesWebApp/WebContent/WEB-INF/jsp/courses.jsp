<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List" %>
<%@ page import="com.example.courses.Course" %>
<%
request.setAttribute("pageTitle", "Courses");
%>
<jsp:include page="/WEB-INF/jsp/_header.jsp" />

<%
List<Course> courses = (List<Course>) request.getAttribute("courses");
%>

<table>
  <thead>
    <tr>
      <th>Title</th>
      <th>Level</th>
      <th>Duration</th>
      <th>Fee</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
  <% if (courses == null || courses.isEmpty()) { %>
    <tr><td colspan="5">No courses available.</td></tr>
  <% } else { 
       for (Course c : courses) { %>
    <tr>
      <td><strong><%= c.getTitle() %></strong></td>
      <td><span class="badge"><%= c.getLevel() %></span></td>
      <td><%= c.getDurationHours() %> hours</td>
      <td>₹ <%= String.format("%.2f", c.getFee()) %></td>
      <td><a href="<%=request.getContextPath()%>/courses/detail?id=<%=c.getId()%>">View</a></td>
    </tr>
  <%   } 
     } %>
  </tbody>
</table>

<jsp:include page="/WEB-INF/jsp/_footer.jsp" />

