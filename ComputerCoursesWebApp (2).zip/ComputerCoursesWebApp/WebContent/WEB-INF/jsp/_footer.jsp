<footer>
  <div>Data is in-memory and resets when Tomcat restarts.</div>
</footer>
</div>
</body>
</html>

