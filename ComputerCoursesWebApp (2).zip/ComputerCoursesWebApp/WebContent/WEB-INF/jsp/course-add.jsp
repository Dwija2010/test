<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
request.setAttribute("pageTitle", "Add Course");
String error = (String) request.getAttribute("error");

String title = (String) request.getAttribute("title");
String level = (String) request.getAttribute("level");
String durationHours = (String) request.getAttribute("durationHours");
String fee = (String) request.getAttribute("fee");
String description = (String) request.getAttribute("description");

if (title == null) title = "";
if (level == null) level = "Beginner";
if (durationHours == null) durationHours = "";
if (fee == null) fee = "";
if (description == null) description = "";
%>
<jsp:include page="/WEB-INF/jsp/_header.jsp" />

<% if (error != null) { %>
  <div class="error"><%= error %></div>
<% } %>

<form method="post" action="<%=request.getContextPath()%>/courses/add">
  <label for="title">Course Title *</label>
  <input id="title" name="title" type="text" value="<%= title %>" placeholder="e.g., Python Basics" />

  <label for="level">Level *</label>
  <select id="level" name="level">
    <option value="Beginner" <%= "Beginner".equals(level) ? "selected" : "" %>>Beginner</option>
    <option value="Intermediate" <%= "Intermediate".equals(level) ? "selected" : "" %>>Intermediate</option>
    <option value="Advanced" <%= "Advanced".equals(level) ? "selected" : "" %>>Advanced</option>
  </select>

  <label for="durationHours">Duration (hours) *</label>
  <input id="durationHours" name="durationHours" type="number" min="1" value="<%= durationHours %>" placeholder="e.g., 20" />

  <label for="fee">Fee (INR)</label>
  <input id="fee" name="fee" type="number" min="0" step="0.01" value="<%= fee %>" placeholder="e.g., 2999" />

  <label for="description">Description</label>
  <textarea id="description" name="description" rows="5" placeholder="What will learners get from this course?"><%= description %></textarea>

  <div style="margin-top:14px;">
    <button class="btn primary" type="submit">Save</button>
    <a class="btn" href="<%=request.getContextPath()%>/courses">Cancel</a>
  </div>
</form>

<jsp:include page="/WEB-INF/jsp/_footer.jsp" />

