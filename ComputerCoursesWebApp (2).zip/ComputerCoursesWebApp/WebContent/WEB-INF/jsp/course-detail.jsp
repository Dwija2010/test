<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.example.courses.Course" %>
<%
request.setAttribute("pageTitle", "Course Details");
Course c = (Course) request.getAttribute("course");
String message = (String) request.getAttribute("message");
%>
<jsp:include page="/WEB-INF/jsp/_header.jsp" />

<% if (message != null) { %>
  <div class="error"><%= message %></div>
<% } %>

<% if (c != null) { %>
  <h3 style="margin-top:0;"><%= c.getTitle() %></h3>
  <div style="margin-bottom:10px;">
    <span class="badge"><%= c.getLevel() %></span>
    &nbsp;•&nbsp; <%= c.getDurationHours() %> hours
    &nbsp;•&nbsp; Fee: ₹ <%= String.format("%.2f", c.getFee()) %>
  </div>
  <div class="info">
    <%= (c.getDescription() == null || c.getDescription().trim().isEmpty()) ? "No description provided." : c.getDescription() %>
  </div>
<% } %>

<jsp:include page="/WEB-INF/jsp/_footer.jsp" />

