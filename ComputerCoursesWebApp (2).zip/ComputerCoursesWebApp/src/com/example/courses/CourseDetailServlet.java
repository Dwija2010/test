package com.example.courses;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CourseDetailServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String idStr = req.getParameter("id");
        int id = 0;
        try { id = Integer.parseInt(idStr); } catch (Exception ignore) {}

        Course course = CourseRepository.getInstance().findById(id);
        if (course == null) {
            req.setAttribute("message", "Course not found.");
        } else {
            req.setAttribute("course", course);
        }
        RequestDispatcher rd = req.getRequestDispatcher("/WEB-INF/jsp/course-detail.jsp");
        rd.forward(req, resp);
    }
}
