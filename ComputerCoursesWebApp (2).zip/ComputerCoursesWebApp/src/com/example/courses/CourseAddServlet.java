package com.example.courses;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CourseAddServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        RequestDispatcher rd = req.getRequestDispatcher("/WEB-INF/jsp/course-add.jsp");
        rd.forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");

        String title = safe(req.getParameter("title"));
        String level = safe(req.getParameter("level"));
        String durationStr = safe(req.getParameter("durationHours"));
        String feeStr = safe(req.getParameter("fee"));
        String description = safe(req.getParameter("description"));

        int duration = parseInt(durationStr, 0);
        double fee = parseDouble(feeStr, 0.0);

        if (title.isEmpty() || level.isEmpty() || duration <= 0) {
            req.setAttribute("error", "Please enter Title, Level and a valid Duration (hours).");
            req.setAttribute("title", title);
            req.setAttribute("level", level);
            req.setAttribute("durationHours", durationStr);
            req.setAttribute("fee", feeStr);
            req.setAttribute("description", description);
            RequestDispatcher rd = req.getRequestDispatcher("/WEB-INF/jsp/course-add.jsp");
            rd.forward(req, resp);
            return;
        }

        Course c = new Course(0, title, level, duration, fee, description);
        CourseRepository.getInstance().add(c);

        // Redirect to list
        resp.sendRedirect(req.getContextPath() + "/courses");
    }

    private String safe(String s) {
        return (s == null) ? "" : s.trim();
    }

    private int parseInt(String s, int def) {
        try { return Integer.parseInt(s); } catch (Exception e) { return def; }
    }

    private double parseDouble(String s, double def) {
        try { return Double.parseDouble(s); } catch (Exception e) { return def; }
    }
}
