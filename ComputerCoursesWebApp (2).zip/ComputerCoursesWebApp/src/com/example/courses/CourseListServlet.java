package com.example.courses;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CourseListServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setAttribute("courses", CourseRepository.getInstance().findAll());
        RequestDispatcher rd = req.getRequestDispatcher("/WEB-INF/jsp/courses.jsp");
        rd.forward(req, resp);
    }
}
