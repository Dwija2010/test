package com.example.courses;

public class Course {
    private int id;
    private String title;
    private String level;
    private int durationHours;
    private double fee;
    private String description;

    public Course() {}

    public Course(int id, String title, String level, int durationHours, double fee, String description) {
        this.id = id;
        this.title = title;
        this.level = level;
        this.durationHours = durationHours;
        this.fee = fee;
        this.description = description;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getLevel() { return level; }
    public void setLevel(String level) { this.level = level; }

    public int getDurationHours() { return durationHours; }
    public void setDurationHours(int durationHours) { this.durationHours = durationHours; }

    public double getFee() { return fee; }
    public void setFee(double fee) { this.fee = fee; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}
