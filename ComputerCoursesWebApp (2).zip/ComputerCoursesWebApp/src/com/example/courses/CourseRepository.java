package com.example.courses;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * In-memory repository (no DB) to keep this project simple.
 * Data resets when Tomcat restarts.
 */
public class CourseRepository {

    private static final CourseRepository INSTANCE = new CourseRepository();

    private final List<Course> courses = new ArrayList<Course>();
    private final AtomicInteger idSeq = new AtomicInteger(1000);

    private CourseRepository() {
        // Seed data
        add(new Course(0, "Java Fundamentals", "Beginner", 30, 4999, "Core Java basics: OOP, collections, exceptions, I/O."));
        add(new Course(0, "Web Development with Servlets & JSP", "Intermediate", 25, 5999, "Build web apps using JSP, JSTL basics, Servlets, MVC."));
        add(new Course(0, "SQL for Developers", "Beginner", 20, 3999, "SQL querying, joins, aggregations, constraints, basic design."));
        add(new Course(0, "Spring Basics (Concepts)", "Intermediate", 18, 6999, "Intro to DI, IoC, MVC concepts (demo-focused, no heavy setup)."));
        add(new Course(0, "Git & GitHub Essentials", "Beginner", 10, 1499, "Version control, branching, pull requests, basic workflows."));
    }

    public static CourseRepository getInstance() {
        return INSTANCE;
    }

    public synchronized List<Course> findAll() {
        // Return an immutable snapshot to avoid accidental modifications in JSP
        return Collections.unmodifiableList(new ArrayList<Course>(courses));
    }

    public synchronized Course findById(int id) {
        for (Course c : courses) {
            if (c.getId() == id) return c;
        }
        return null;
    }

    public synchronized Course add(Course course) {
        if (course.getId() <= 0) {
            course.setId(idSeq.incrementAndGet());
        }
        courses.add(course);
        return course;
    }
}
