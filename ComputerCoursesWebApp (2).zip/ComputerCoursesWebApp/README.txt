ComputerCoursesWebApp (Tomcat 7 / Java 8)

Features:
- List courses
- View course details
- Add a new course (in-memory storage)

URLs:
- /ComputerCoursesWebApp/  -> redirects to /courses
- /ComputerCoursesWebApp/courses
- /ComputerCoursesWebApp/courses/detail?id=...
- /ComputerCoursesWebApp/courses/add

Note: Data resets when Tomcat restarts.
