<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title><%= (request.getAttribute("pageTitle") == null ? "Computer Courses" : request.getAttribute("pageTitle")) %></title>
  <style>
    body { font-family: Arial, sans-serif; margin: 24px; }
    .container { max-width: 980px; margin: 0 auto; }
    header { display:flex; align-items:center; justify-content:space-between; margin-bottom:16px; }
    a { color: #0b57d0; text-decoration:none; }
    a:hover { text-decoration:underline; }
    table { border-collapse: collapse; width: 100%; }
    th, td { border: 1px solid #ddd; padding: 10px; }
    th { background: #f6f6f6; text-align:left; }
    .badge { display:inline-block; padding:2px 8px; border-radius:12px; background:#eee; font-size:12px; }
    .actions { display:flex; gap:12px; }
    .btn { display:inline-block; padding:8px 12px; border:1px solid #ddd; border-radius:6px; background:#fff; }
    .btn.primary { border-color:#0b57d0; }
    .error { padding:10px; border:1px solid #d93025; background:#fce8e6; border-radius:6px; margin:12px 0; }
    .info { padding:10px; border:1px solid #1a73e8; background:#e8f0fe; border-radius:6px; margin:12px 0; }
    input, textarea, select { width:100%; padding:10px; border:1px solid #ddd; border-radius:6px; box-sizing:border-box; }
    label { font-weight:bold; display:block; margin:10px 0 6px; }
    form { max-width: 720px; }
    footer { margin-top: 24px; color:#666; font-size:12px; }
  </style>
</head>
<body>
<div class="container">
<header>
  <div>
    <h2 style="margin:0;">Computer Courses</h2>
    <div style="color:#666; font-size:13px;">Simple JSP/Servlet demo (Tomcat 7, Java 8)</div>
  </div>
  <div class="actions">
    <a class="btn" href="<%=request.getContextPath()%>/courses">All Courses</a>
    <a class="btn primary" href="<%=request.getContextPath()%>/courses/add">Add Course</a>
  </div>
</header>

