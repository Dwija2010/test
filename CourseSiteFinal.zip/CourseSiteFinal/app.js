
const imgs=document.querySelectorAll('.course-image');
imgs.forEach(img=>{
 img.addEventListener('click',()=>{
   img.parentElement.querySelector('.details').classList.toggle('open');
 });
});
