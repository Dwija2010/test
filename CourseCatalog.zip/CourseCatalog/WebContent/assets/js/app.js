(function () {
  function toggleCard(card) {
    const btn = card.querySelector(".imgBtn");
    const details = card.querySelector(".details");
    const expanded = btn.getAttribute("aria-expanded") === "true";

    // Optional: collapse all others (single-open behavior)
    document.querySelectorAll(".card").forEach(c => {
      if (c !== card) {
        const b = c.querySelector(".imgBtn");
        const d = c.querySelector(".details");
        b.setAttribute("aria-expanded", "false");
        d.hidden = true;
      }
    });

    btn.setAttribute("aria-expanded", String(!expanded));
    details.hidden = expanded;
  }

  document.querySelectorAll(".card .imgBtn").forEach(btn => {
    btn.addEventListener("click", (e) => {
      const card = e.currentTarget.closest(".card");
      toggleCard(card);
    });
  });
})();
