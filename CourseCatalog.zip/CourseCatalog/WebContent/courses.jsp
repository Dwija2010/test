<%@ page import="java.util.List" %>
<%@ page import="com.capco.coursecatalog.Course" %>
<%
    @SuppressWarnings("unchecked")
    List<Course> courses = (List<Course>) request.getAttribute("courses");
%>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Course Catalog</title>
  <link rel="stylesheet" href="assets/css/style.css" />
</head>
<body>
  <header class="header">
    <div class="container">
      <h1>Course Catalog</h1>
      <p class="sub">Click any course image to expand details.</p>
    </div>
  </header>

  <main class="container">
    <div class="grid">
      <% if (courses != null) { for (Course c : courses) { %>
        <article class="card" data-course-id="<%= c.getId() %>">
          <button class="imgBtn" type="button" aria-expanded="false" aria-controls="details-<%= c.getId() %>">
            <img src="<%= c.getImagePath() %>" alt="<%= c.getTitle() %> cover" loading="lazy" />
          </button>

          <div class="cardBody">
            <h2 class="title"><%= c.getTitle() %></h2>
            <p class="short"><%= c.getShortDesc() %></p>

            <section class="details" id="details-<%= c.getId() %>" hidden>
              <div class="meta">
                <span><strong>Duration:</strong> <%= c.getDuration() %></span>
                <span><strong>Level:</strong> <%= c.getLevel() %></span>
              </div>
              <p class="long"><%= c.getLongDesc() %></p>
              <p class="pre"><strong>Prerequisites:</strong> <%= c.getPrerequisites() %></p>
            </section>
          </div>
        </article>
      <% } } %>
    </div>
  </main>

  <footer class="footer">
    <div class="container">
      <small>Sample Java web app (Servlet + JSP). Edit courses in <code>CourseServlet.java</code>.</small>
    </div>
  </footer>

  <script src="assets/js/app.js"></script>
</body>
</html>
