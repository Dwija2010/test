CourseCatalog (Servlet + JSP)
=============================

What it does
- Shows a course catalog page.
- Student clicks a course image -> expands/collapses details.

How to run in Eclipse (Tomcat)
1) Install Eclipse IDE for Enterprise Java and Web Developers.
2) Install/Configure Apache Tomcat (recommended Tomcat 10+ for Jakarta).
3) File -> Import -> Existing Projects into Workspace -> select this folder.
4) Right click project -> Properties -> Project Facets -> enable "Dynamic Web Module".
5) Right click project -> Run As -> Run on Server.
6) Open: http://localhost:8080/CourseCatalog/courses

Edit courses
- src/com/capco/coursecatalog/CourseServlet.java
Images
- WebContent/assets/img/*.png
