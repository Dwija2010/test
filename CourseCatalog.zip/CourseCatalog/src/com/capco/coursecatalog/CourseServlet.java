package com.capco.coursecatalog;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Simple servlet that loads course data and forwards to the JSP.
 *
 * Note:
 * - Uses Jakarta Servlet API (Tomcat 10+).
 * - If you are on Tomcat 9 or older, switch imports from jakarta.* to javax.*
 */
@WebServlet(name = "CourseServlet", urlPatterns = {"/courses"})
public class CourseServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Course> courses = new ArrayList<>();

        courses.add(new Course(
                "java",
                "Java Foundations",
                "Learn core Java syntax, OOP, and collections.",
                "This course covers Java basics (types, operators, control flow), object-oriented programming, "
                        + "exception handling, collections, generics, and basic I/O. You'll build small console "
                        + "apps and practice writing clean, testable code.",
                "4 weeks",
                "Beginner",
                "Basic programming familiarity recommended",
                "assets/img/java.png"
        ));

        courses.add(new Course(
                "web",
                "Web Development (HTML/CSS/JS)",
                "Build responsive websites with modern UI patterns.",
                "Hands-on web development: semantic HTML, responsive CSS, Flexbox/Grid, accessible components, "
                        + "vanilla JavaScript for interactivity, DOM manipulation, events, and basic client-side "
                        + "state. You'll implement an interactive course catalog UI.",
                "3 weeks",
                "Beginner–Intermediate",
                "None",
                "assets/img/web.png"
        ));

        courses.add(new Course(
                "sql",
                "SQL & Databases",
                "Query data, design schemas, and understand transactions.",
                "Learn relational database fundamentals, normalization, joins, aggregation, indexes, "
                        + "constraints, and transaction concepts. Includes practical exercises with sample datasets "
                        + "and real-world reporting queries.",
                "3 weeks",
                "Beginner",
                "None",
                "assets/img/sql.png"
        ));

        courses.add(new Course(
                "spring",
                "Spring Boot API Development",
                "Create REST APIs with Spring Boot and best practices.",
                "Build RESTful services using Spring Boot: controllers, DTOs, validation, persistence with JPA, "
                        + "error handling, logging, and basic security concepts. Includes a mini-project and "
                        + "guidance on packaging and deployment.",
                "5 weeks",
                "Intermediate",
                "Java Foundations (or equivalent)",
                "assets/img/spring.png"
        ));

        request.setAttribute("courses", courses);

        RequestDispatcher rd = request.getRequestDispatcher("/courses.jsp");
        rd.forward(request, response);
    }
}
