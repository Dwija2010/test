package com.capco.coursecatalog;

public class Course {
    private final String id;
    private final String title;
    private final String shortDesc;
    private final String longDesc;
    private final String duration;
    private final String level;
    private final String prerequisites;
    private final String imagePath;

    public Course(String id, String title, String shortDesc, String longDesc,
                  String duration, String level, String prerequisites, String imagePath) {
        this.id = id;
        this.title = title;
        this.shortDesc = shortDesc;
        this.longDesc = longDesc;
        this.duration = duration;
        this.level = level;
        this.prerequisites = prerequisites;
        this.imagePath = imagePath;
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getShortDesc() { return shortDesc; }
    public String getLongDesc() { return longDesc; }
    public String getDuration() { return duration; }
    public String getLevel() { return level; }
    public String getPrerequisites() { return prerequisites; }
    public String getImagePath() { return imagePath; }
}
